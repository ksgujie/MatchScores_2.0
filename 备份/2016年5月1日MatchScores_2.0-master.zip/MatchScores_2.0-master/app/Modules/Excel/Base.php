<?php namespace App\Modules\Excel;

require_once app_path() . '/Libs/PHPExcel/PHPExcel.php';

class Base {
	
}