<html>
<head>

    <title>计分 V2</title>
    <link href="{{ asset('/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
    <script href="{{ asset('/js/jquery.min.css') }}"></script>
    <script href="{{ asset('/js/bootstrap.min.css') }}"></script>
</head>
<body>
<h1>科技模型竞赛计分系统 V2</h1>

@include('_message')
	
@yield('content')

</body>
</html>
